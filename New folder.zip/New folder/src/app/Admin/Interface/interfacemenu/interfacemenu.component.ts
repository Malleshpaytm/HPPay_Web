import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interfacemenu',
  templateUrl: './interfacemenu.component.html',
  styleUrls: ['./interfacemenu.component.css']
})
export class InterfacemenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
