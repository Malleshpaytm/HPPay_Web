import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-cardless-dashboad',
  templateUrl: './manage-cardless-dashboad.component.html',
  styleUrls: ['./manage-cardless-dashboad.component.css']
})
export class ManageCardlessDashboadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
