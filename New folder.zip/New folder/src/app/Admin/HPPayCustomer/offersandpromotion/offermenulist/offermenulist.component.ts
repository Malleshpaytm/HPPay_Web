import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offermenulist',
  templateUrl: './offermenulist.component.html',
  styleUrls: ['./offermenulist.component.css']
})
export class OffermenulistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
