import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createoffers',
  templateUrl: './createoffers.component.html',
  styleUrls: ['./createoffers.component.css']
})
export class CreateoffersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
