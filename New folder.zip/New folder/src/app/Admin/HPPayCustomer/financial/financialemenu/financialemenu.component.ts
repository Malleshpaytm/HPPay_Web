import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financialemenu',
  templateUrl: './financialemenu.component.html',
  styleUrls: ['./financialemenu.component.css']
})
export class FinancialemenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
