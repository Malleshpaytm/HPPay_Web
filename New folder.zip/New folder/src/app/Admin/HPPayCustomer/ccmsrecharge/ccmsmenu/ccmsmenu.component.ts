import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ccmsmenu',
  templateUrl: './ccmsmenu.component.html',
  styleUrls: ['./ccmsmenu.component.css']
})
export class CcmsmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
