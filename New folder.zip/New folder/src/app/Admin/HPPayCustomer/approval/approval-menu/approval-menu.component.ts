import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approval-menu',
  templateUrl: './approval-menu.component.html',
  styleUrls: ['./approval-menu.component.css']
})
export class ApprovalMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
