import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedbackmenu',
  templateUrl: './feedbackmenu.component.html',
  styleUrls: ['./feedbackmenu.component.css']
})
export class FeedbackmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
