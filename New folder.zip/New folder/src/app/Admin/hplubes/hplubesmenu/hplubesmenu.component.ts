import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hplubesmenu',
  templateUrl: './hplubesmenu.component.html',
  styleUrls: ['./hplubesmenu.component.css']
})
export class HplubesmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
