import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-downloadmenu',
  templateUrl: './downloadmenu.component.html',
  styleUrls: ['./downloadmenu.component.css']
})
export class DownloadmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
