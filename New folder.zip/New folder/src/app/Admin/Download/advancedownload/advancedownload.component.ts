import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advancedownload',
  templateUrl: './advancedownload.component.html',
  styleUrls: ['./advancedownload.component.css']
})
export class AdvancedownloadComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
