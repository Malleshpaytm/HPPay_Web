import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fastag-profile-menu',
  templateUrl: './fastag-profile-menu.component.html',
  styleUrls: ['./fastag-profile-menu.component.css']
})
export class FastagProfileMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
