import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approvalmenu',
  templateUrl: './approvalmenu.component.html',
  styleUrls: ['./approvalmenu.component.css']
})
export class ApprovalmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
