import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestcard',
  templateUrl: './requestcard.component.html',
  styleUrls: ['./requestcard.component.css']
})
export class RequestcardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
