import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financialmenu',
  templateUrl: './financialmenu.component.html',
  styleUrls: ['./financialmenu.component.css']
})
export class FinancialmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
