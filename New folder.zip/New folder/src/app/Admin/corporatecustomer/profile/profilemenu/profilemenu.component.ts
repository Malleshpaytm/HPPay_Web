import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilemenu',
  templateUrl: './profilemenu.component.html',
  styleUrls: ['./profilemenu.component.css']
})
export class ProfilemenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
