import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerbonusmenu',
  templateUrl: './customerbonusmenu.component.html',
  styleUrls: ['./customerbonusmenu.component.css']
})
export class CustomerbonusmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
