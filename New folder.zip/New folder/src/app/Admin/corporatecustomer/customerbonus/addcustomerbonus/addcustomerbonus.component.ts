import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addcustomerbonus',
  templateUrl: './addcustomerbonus.component.html',
  styleUrls: ['./addcustomerbonus.component.css']
})
export class AddcustomerbonusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
