import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchantprofilemenlist',
  templateUrl: './merchantprofilemenlist.component.html',
  styleUrls: ['./merchantprofilemenlist.component.css']
})
export class MerchantprofilemenlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
