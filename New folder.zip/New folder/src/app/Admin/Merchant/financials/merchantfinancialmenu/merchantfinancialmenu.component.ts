import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchantfinancialmenu',
  templateUrl: './merchantfinancialmenu.component.html',
  styleUrls: ['./merchantfinancialmenu.component.css']
})
export class MerchantfinancialmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
