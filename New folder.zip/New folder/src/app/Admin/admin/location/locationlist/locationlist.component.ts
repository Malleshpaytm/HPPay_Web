import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-locationlist',
  templateUrl: './locationlist.component.html',
  styleUrls: ['./locationlist.component.css']
})
export class LocationlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
