import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addeditservice',
  templateUrl: './addeditservice.component.html',
  styleUrls: ['./addeditservice.component.css']
})
export class AddeditserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
