import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-configurationmenu',
  templateUrl: './configurationmenu.component.html',
  styleUrls: ['./configurationmenu.component.css']
})
export class ConfigurationmenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
