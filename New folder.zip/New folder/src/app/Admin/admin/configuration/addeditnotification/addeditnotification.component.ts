import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addeditnotification',
  templateUrl: './addeditnotification.component.html',
  styleUrls: ['./addeditnotification.component.css']
})
export class AddeditnotificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
