import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-officerlist',
  templateUrl: './officerlist.component.html',
  styleUrls: ['./officerlist.component.css']
})
export class OfficerlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
