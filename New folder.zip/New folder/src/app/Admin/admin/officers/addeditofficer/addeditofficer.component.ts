import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addeditofficer',
  templateUrl: './addeditofficer.component.html',
  styleUrls: ['./addeditofficer.component.scss']
})
export class AddeditofficerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
