import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auditlist',
  templateUrl: './auditlist.component.html',
  styleUrls: ['./auditlist.component.css']
})
export class AuditlistComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
    
  }

 
}
