import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-role',
  templateUrl: './add-edit-role.component.html',
  styleUrls: ['./add-edit-role.component.css'],
})
export class AddEditRoleComponent implements OnInit {
  panelOpenState: boolean = false;

  constructor() {}

  ngOnInit(): void {}
}
