import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportmailinfo',
  templateUrl: './reportmailinfo.component.html',
  styleUrls: ['./reportmailinfo.component.css']
})
export class ReportmailinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
