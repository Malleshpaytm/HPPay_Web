import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addeditprofiledetail',
  templateUrl: './addeditprofiledetail.component.html',
  styleUrls: ['./addeditprofiledetail.component.css']
})
export class AddeditprofiledetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
