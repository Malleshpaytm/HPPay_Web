import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addeditreportconfiguration',
  templateUrl: './addeditreportconfiguration.component.html',
  styleUrls: ['./addeditreportconfiguration.component.css']
})
export class AddeditreportconfigurationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
