import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setupreportlist',
  templateUrl: './setupreportlist.component.html',
  styleUrls: ['./setupreportlist.component.css']
})
export class SetupreportlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
